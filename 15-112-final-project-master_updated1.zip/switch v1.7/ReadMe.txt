to run simply double click "switchv16.py"

incase the window is too large or too small you can change the window height/width in the code 